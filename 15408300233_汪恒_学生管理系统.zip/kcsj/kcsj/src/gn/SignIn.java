package gn;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import db.MysqlConn;
import student.main.ProjectMain;
import student.main.StudentMain;
import util.SoundUtil;

/**
 * ע��������
 * @author
 *
 */
public class SignIn extends JPanel implements ActionListener{
	SoundUtil sound;
	public int i=0;
	private JTextField textField;
	private JPasswordField passwordField;
	private JButton button = new JButton("��¼");
	private JButton button1=new JButton("����");
	public JTextField jt=new JTextField();
	
	public SignIn() {
		jt.setVisible(false);
		setBounds(100, 100, 420, 250);
		this.setLayout(null);	
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(0, 0, 414, 241-20-20);
		this.add(panel);	
		
		this.add(jt);
		JLabel lblNewLabel = new JLabel("�˺�");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 15));
		lblNewLabel.setBounds(68, 95-20-20-20, 38, 37);
		panel.add(lblNewLabel);
		
		JLabel label_1 = new JLabel("����");
		label_1.setFont(new Font("����", Font.BOLD, 15));
		label_1.setBounds(68, 145-20-20-20, 38, 37);
		panel.add(label_1);
		
		textField = new JTextField();
		textField.setBounds(115, 100-20-20-20, 181, 29);
		panel.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(115, 150-20-20-20, 181, 29);
		panel.add(passwordField);
		
		
		button.setFont(new Font("����", Font.BOLD, 14));
		button.setBounds(90, 201-20-20-20, 75, 30);
		panel.add(button);
	
		button1.setFont(new Font("����", Font.BOLD, 14));
		button1.setBounds(210, 201-20-20-20, 75, 30);
		panel.add(button1);
		
		button.addActionListener(this);
		button1.addActionListener(this);
	}


	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==button){
			if((textField.getText().equals("sys"))&&(new String(passwordField.getPassword()).equals("123"))){
				jt.setText("ͨ��");
				new ProjectMain();
				sound=new SoundUtil("msc//133.mid");
			}else if(MysqlConn.isUser(textField.getText(), new String(passwordField.getPassword()))){
				jt.setText("ͨ��");
				String xueshengzhanghao=textField.getText().toString();
				new StudentMain(xueshengzhanghao);
			}else{
				JOptionPane.showMessageDialog(null, "��¼ʧ�ܣ������˺Ż�������󣡣���", "����", JOptionPane.ERROR_MESSAGE);
				textField.setText("");
				passwordField.setText("");
			}
		}
		if(e.getSource()==button1){
			textField.setText("");
			passwordField.setText("");
		}
	}
}

		