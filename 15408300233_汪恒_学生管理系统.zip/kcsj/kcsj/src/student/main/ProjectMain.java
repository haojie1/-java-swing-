package student.main;
/**
 * 管理员主界面
 */
import javax.swing.*;

import gn.soundPlayer;
import util.FrameShowCenterUtil;
import util.FrameToumingPanelUtil;
import util.HomePanelUtil;

import java.awt.*;
import java.awt.event.*;

public class ProjectMain extends JFrame implements ActionListener{
	private FrameToumingPanelUtil jpHead,jpLeft,jpMain;
	private JPanel jpFoot;
	private JLabel jlHead,jlFoot,jlMain;
	private JButton jbStudent,jbScore,jbCourse,jbCancel;
	private Container con;
	private BorderLayout bor;
	private soundPlayer sp;

	public ProjectMain(){

		super("软件二班学生成绩系统");
		bor=new BorderLayout();
		jpHead=new FrameToumingPanelUtil();
		jpLeft=new FrameToumingPanelUtil();
		jpMain=new FrameToumingPanelUtil();
		jpFoot=new JPanel();
		jlHead=new JLabel("学生成绩管理系统");
		jlFoot=new JLabel("Copright©2017  湖南工业大学软件工程1502班汪恒 .All right reserved");
		jbStudent=new JButton("学生管理");
		jbScore=new JButton("成绩管理");
		jbCourse=new JButton("课程管理");
		jbCancel=new JButton("退  出");
		con=this.getContentPane();
		con.setLayout(null);
		HomePanelUtil hpMain=new HomePanelUtil("img/timg.jpg",1200,800);
		con.add(hpMain);
		
		jpHead.setLayout(null);
		jpHead.add(jlHead);
		jlHead.setBounds(250, 35, 800, 90);
		jlHead.setFont(new Font("宋体",Font.BOLD,85));
		hpMain.add(jpHead);
		jpHead.setBounds(0, 0, 1194, 150);
		jpHead.setBackground(Color.pink);
		jpHead.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		jpLeft.setLayout(null);
		jpLeft.add(jbStudent);
		jbStudent.setBounds(45, 120, 110, 40);
		jbStudent.setFont(new Font("宋体",Font.BOLD,16));
		jpLeft.add(jbScore);
		jbScore.setBounds(45, 220, 110, 40);
		jbScore.setFont(new Font("宋体",Font.BOLD,16));
		jpLeft.add(jbCourse);
		jbCourse.setBounds(45, 320, 110, 40);
		jbCourse.setFont(new Font("宋体",Font.BOLD,16));
		jpLeft.add(jbCancel);
		jbCancel.setBounds(45, 420, 110, 40);
		jbCancel.setFont(new Font("宋体",Font.BOLD,16));
		
		hpMain.add(jpLeft);
		jpLeft.setBounds(0, 152, 200, 590);
		jpLeft.setBorder(BorderFactory.createLineBorder(Color.black));
		
		hpMain.add(jpMain);
		jpMain.setBounds(202, 152, 992, 590);
		jpMain.setBorder(BorderFactory.createLineBorder(Color.black));
		
		jpFoot.add(jlFoot);
		jlFoot.setFont(new Font("宋体",Font.BOLD,16));
		hpMain.add(jpFoot);
		jpFoot.setBackground(null);                      // 把背景设置为会  
		jpFoot.setOpaque(false); 
		jpFoot.setBounds(0, 741, 1194, 52);
		jpFoot.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		jbStudent.addActionListener(this);
		jbScore.addActionListener(this);
		jbCourse.addActionListener(this);
		jbCancel.addActionListener(this);
		
		FrameShowCenterUtil.showCenter(this, 1200, 800);
	}
	
	
	public static void main(String[] args) {
		ProjectMain sm=new ProjectMain();
	}


	@Override
	public void actionPerformed(ActionEvent e) {

		if(e.getSource()==jbStudent){
			jpMain.removeAll();
			TeacherStudentPanel p=new TeacherStudentPanel();
			jpMain.setLayout(null);
			jpMain.add(p);			
			this.repaint();
			this.validate();			
		}
		if(e.getSource()==jbScore){
			jpMain.removeAll();			
			TeacherScorePanel p=new TeacherScorePanel();
			jpMain.setLayout(null);
			jpMain.add(p);
			this.repaint();
			this.validate();
		}
		if(e.getSource()==jbCourse){
			jpMain.removeAll();
			TeacherCoursePanel p=new TeacherCoursePanel();
			jpMain.setLayout(null);
			jpMain.add(p);
			this.repaint();
			this.validate();
		}
		if(e.getSource()==jbCancel){
			this.dispose();
			new Login();
		}
	}
}