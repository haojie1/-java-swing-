package student.main;
/**
 * ��ʦ�����γ����
 */
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import javax.swing.*;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import bean.Course;
import bean.Score;
import bean.Student;
import db.MysqlConn;
import db.MysqlConn.SelectListener;
import util.FrameToumingPanelUtil;

public class TeacherCoursePanel extends JPanel {
	private JLabel jlDeleteCourse,jlUpdateCourse,jlAddCourse;
	private JComboBox jcbDeleteCName,jcbUpdateCName;
	private JTextField jtUpdateCourseXS,jtUpdateCourseXF,jtAddCourseName,jtAddCourseXS,jtAddCourseXF;
	private JButton jbDeleteCourse,jbAdd,jbUpdateCourse;
	String[] score=null;
	String[] field={"�γ���","ѧʱ","ѧ   ��"};
	Object[][] data={};
	private DefaultTableModel mod;
	private JTable tab;
	private JScrollPane jsp;
	private Font font;
	private JLabel jp;
	public static int temp=0;
	
	public TeacherCoursePanel(){
		font=new Font("����",Font.BOLD,16);
		this.setLayout(null);
		mod=new DefaultTableModel(data,field);
		tab=new JTable(mod);
		tab.setBackground(null);                      // �ѱ�������Ϊ��  
		tab.setOpaque(false);
		jsp=new JScrollPane();
		jsp.getViewport().add(tab);
		tab.setEnabled(false);
		List<Course> list=MysqlConn.selectCourse();
		while(mod.getRowCount()>0) {
			mod.removeRow(0);
		}
		for(int j=0;j<list.size();j++) {
			mod.addRow(new Object[] {list.get(j).getKcm(),list.get(j).getXs(),list.get(j).getXf()});
		}
		if(mod.getRowCount()<60){
			for(int i=0;i<60-mod.getRowCount();i++){
				mod.addRow(new Object[] {,});
			}
		}
		
		jp=new JLabel();
		jlDeleteCourse=new JLabel("ɾ���γ̣�");
		jlDeleteCourse.setFont(font);
		jlUpdateCourse=new JLabel("�޸Ŀγ̣�");
		jlUpdateCourse.setFont(font);
		jlAddCourse=new JLabel("���ӿγ̣�");
		jlAddCourse.setFont(font);
		
		score = MysqlConn.selectKcm();
		jcbDeleteCName=new JComboBox(score);
		jcbUpdateCName=new JComboBox(score);
		
		jtUpdateCourseXS=new JTextField("������ѧʱ");
		String info1="������ѧʱ";
		jtUpdateCourseXS.addFocusListener(new MyFocusListener(info1,jtUpdateCourseXS));
		jtUpdateCourseXF=new JTextField("������ѧ��");
		jtUpdateCourseXS.setForeground(Color.LIGHT_GRAY);
		jtUpdateCourseXF.setForeground(Color.LIGHT_GRAY);
		String info2="������ѧ��";
		jtUpdateCourseXF.addFocusListener(new MyFocusListener(info2,jtUpdateCourseXF));
		jbUpdateCourse=new JButton("�޸�");
		jbUpdateCourse.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
					if(((!jtUpdateCourseXS.getText().toString().equals(""))||(!jtUpdateCourseXS.getText().toString().equals("������ѧʱ")))
							&&((!jtUpdateCourseXF.getText().toString().equals(""))||(!jtUpdateCourseXF.getText().toString().equals("������ѧ��")))){
						try{						
							if(!((Integer.valueOf(jtUpdateCourseXS.getText().toString())<0||Integer.valueOf(jtUpdateCourseXS.getText().toString())>100)
									||(Integer.valueOf(jtUpdateCourseXF.getText().toString())<0||Integer.valueOf(jtUpdateCourseXF.getText().toString())>10))){
								boolean isSuccess=MysqlConn.updateCourse(jcbUpdateCName.getSelectedItem().toString(),
										Integer.valueOf(jtUpdateCourseXS.getText().toString()),Integer.valueOf(jtUpdateCourseXF.getText().toString()));
								if(isSuccess==true){
									List<Course> list=MysqlConn.selectCourse();
									while(mod.getRowCount()>0) {
										mod.removeRow(0);
									}
									for(int j=0;j<list.size();j++) {
										mod.addRow(new Object[] {list.get(j).getKcm(),list.get(j).getXs(),list.get(j).getXf()});
									}
									if(mod.getRowCount()<60){
										for(int i=0;i<60-mod.getRowCount();i++){
											mod.addRow(new Object[] {,});
										}
									}
									String[] sc = MysqlConn.selectKcm();
									jcbDeleteCName=new JComboBox<Object>(sc);
									jcbUpdateCName=new JComboBox<Object>(sc);								
									
									jtUpdateCourseXF.setText("������ѧ��");
									jtUpdateCourseXS.setText("������ѧʱ");	
									jtUpdateCourseXS.setForeground(Color.LIGHT_GRAY);
									jtUpdateCourseXF.setForeground(Color.LIGHT_GRAY);
								
								}else{
									System.out.println("11111111111111111111");
								}
								
							}else{
								JOptionPane.showMessageDialog(null,"�޸�ʧ��,ѧʱӦ��0-100֮��,ѧ��Ӧ��0-10֮��","����",JOptionPane.ERROR_MESSAGE);
								jtUpdateCourseXF.setText("������ѧ��");
								jtUpdateCourseXS.setText("������ѧʱ");
								jtUpdateCourseXS.setForeground(Color.LIGHT_GRAY);
								jtUpdateCourseXF.setForeground(Color.LIGHT_GRAY);
							}
						}catch(Exception e1){
							JOptionPane.showMessageDialog(null,"�޸�ʧ��,ѧʱѧ��ӦΪ����","����",JOptionPane.ERROR_MESSAGE);
							jtUpdateCourseXF.setText("������ѧ��");
							jtUpdateCourseXS.setText("������ѧʱ");
							jtUpdateCourseXS.setForeground(Color.LIGHT_GRAY);
							jtUpdateCourseXF.setForeground(Color.LIGHT_GRAY);
						}
						
					}else{
						JOptionPane.showMessageDialog(null,"�޸�ʧ��,������ѧʱѧ��","����",JOptionPane.ERROR_MESSAGE);
						jtUpdateCourseXF.setText("������ѧ��");
						jtUpdateCourseXS.setText("������ѧʱ");
						jtUpdateCourseXS.setForeground(Color.LIGHT_GRAY);
						jtUpdateCourseXF.setForeground(Color.LIGHT_GRAY);
					}			
			}
		});
		
		jtAddCourseName=new JTextField("������γ���");
		String info3="������γ���";
		jtAddCourseName.addFocusListener(new MyFocusListener(info3,jtAddCourseName));
		jtAddCourseXS=new JTextField("������ѧʱ");
		jtAddCourseXS.addFocusListener(new MyFocusListener(info1,jtAddCourseXS));
		jtAddCourseXF=new JTextField("������ѧ��");
		jtAddCourseName.setForeground(Color.LIGHT_GRAY);
		jtAddCourseXS.setForeground(Color.LIGHT_GRAY);
		jtAddCourseXF.setForeground(Color.LIGHT_GRAY);
		jtAddCourseXF.addFocusListener(new MyFocusListener(info2,jtAddCourseXF));
		
		
		jbDeleteCourse=new JButton("ɾ��");
		jbDeleteCourse.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int res=JOptionPane.showConfirmDialog(null, "ɾ���γ̽�ɾ����Ӧѧ���ɼ�", "�Ƿ����", JOptionPane.YES_NO_OPTION);
                if(res==JOptionPane.YES_OPTION){  
                	MysqlConn.deleteCourse(jcbDeleteCName.getSelectedItem().toString());
                	List<Course> list=MysqlConn.selectCourse();
					while(mod.getRowCount()>0) {
						mod.removeRow(0);
					}
					for(int j=0;j<list.size();j++) {
						mod.addRow(new Object[] {list.get(j).getKcm(),list.get(j).getXs(),list.get(j).getXf()});
					}
					if(mod.getRowCount()<60){
						for(int i=0;i<60-mod.getRowCount();i++){
							mod.addRow(new Object[] {,});
						}
					}
					String[] sc = MysqlConn.selectKcm();
					jcbDeleteCName.removeAllItems();
					jcbUpdateCName.removeAllItems();
					for(int i=0;i<sc.length;i++){
						jcbDeleteCName.addItem(sc[i]);
						jcbUpdateCName.addItem(sc[i]);
					}
                }else{                 
                    return;
                }
			}			
			
		});
		
		jbAdd=new JButton("����");
		jbAdd.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if((!jtAddCourseName.getText().toString().equals(""))||(!jtAddCourseName.getText().toString().equals("������ѧʱ"))){
					if(((!jtAddCourseXS.getText().toString().equals(""))||(!jtAddCourseXS.getText().toString().equals("������ѧʱ")))
							&&((!jtAddCourseXF.getText().toString().equals(""))||(!jtAddCourseXF.getText().toString().equals("������ѧ��")))){
						try{						
							if(!((Integer.valueOf(jtAddCourseXS.getText().toString())<0||Integer.valueOf(jtAddCourseXS.getText().toString())>100)
									||(Integer.valueOf(jtAddCourseXF.getText().toString())<0||Integer.valueOf(jtAddCourseXF.getText().toString())>10))){
								boolean isSuccess=MysqlConn.addCourse(jtAddCourseName.getText().toString(),jtAddCourseXS.getText().toString(),jtAddCourseXF.getText().toString());
								if(isSuccess==true){
									List<Course> list=MysqlConn.selectCourse();
									while(mod.getRowCount()>0) {
										mod.removeRow(0);
									}
									for(int j=0;j<list.size();j++) {
										mod.addRow(new Object[] {list.get(j).getKcm(),list.get(j).getXs(),list.get(j).getXf()});
									}
									if(mod.getRowCount()<60){
										for(int i=0;i<60-mod.getRowCount();i++){
											mod.addRow(new Object[] {,});
										}
									}
									String[] sc = MysqlConn.selectKcm();
									jcbDeleteCName.removeAllItems();
									jcbUpdateCName.removeAllItems();
									for(int i=0;i<sc.length;i++){
										jcbDeleteCName.addItem(sc[i]);
										jcbUpdateCName.addItem(sc[i]);
									}								

									
									jtAddCourseName.setText("������γ���");
									jtAddCourseXF.setText("������ѧ��");
									jtAddCourseXS.setText("������ѧʱ");
									jtAddCourseName.setForeground(Color.LIGHT_GRAY);
									jtAddCourseXS.setForeground(Color.LIGHT_GRAY);
									jtAddCourseXF.setForeground(Color.LIGHT_GRAY);
									
								}else{
									JOptionPane.showMessageDialog(null,"����ʧ��,�ÿγ��Ѿ�����","����",JOptionPane.ERROR_MESSAGE);
									jtAddCourseName.setText("������γ���");
									jtAddCourseName.setForeground(Color.LIGHT_GRAY);
								
								}
								
							}else{
								JOptionPane.showMessageDialog(null,"����ʧ��,ѧʱӦ��0-100֮��,ѧ��Ӧ��0-10֮��","����",JOptionPane.ERROR_MESSAGE);
								jtAddCourseXF.setText("������ѧ��");
								jtAddCourseXS.setText("������ѧʱ");
								
								jtAddCourseXS.setForeground(Color.LIGHT_GRAY);
								jtAddCourseXF.setForeground(Color.LIGHT_GRAY);
							}
						}catch(Exception e1){
							JOptionPane.showMessageDialog(null,"����ʧ��,ѧʱѧ��ӦΪ����","����",JOptionPane.ERROR_MESSAGE);
							jtAddCourseXF.setText("������ѧ��");
							jtAddCourseXS.setText("������ѧʱ");
							jtAddCourseXS.setForeground(Color.LIGHT_GRAY);
							jtAddCourseXF.setForeground(Color.LIGHT_GRAY);
						}
						
					}else{
						JOptionPane.showMessageDialog(null,"����ʧ��,������ѧʱѧ��","����",JOptionPane.ERROR_MESSAGE);
						jtAddCourseXF.setText("������ѧ��");
						jtAddCourseXS.setText("������ѧʱ");
						jtAddCourseXS.setForeground(Color.LIGHT_GRAY);
						jtAddCourseXF.setForeground(Color.LIGHT_GRAY);
					}
				}else{
					JOptionPane.showMessageDialog(null,"����ʧ��,��������ȷ�γ���","����",JOptionPane.ERROR_MESSAGE);
					jtAddCourseName.setText("������γ���");
					jtAddCourseName.setForeground(Color.LIGHT_GRAY);
				}
			}	
		});
		this.add(jsp);
		jsp.setBounds(450-370, 50, 385, 480);
		
		this.add(jlDeleteCourse);
		jlDeleteCourse.setBounds(80+450, 35+50, 90, 60);
		this.add(jcbDeleteCName);
		jcbDeleteCName.setBounds(170+450, 50+50, 222+5, 30);
		this.add(jbDeleteCourse);
		jbDeleteCourse.setBounds(845+5, 50+50, 60, 30);
		
		this.add(jlUpdateCourse);
		jlUpdateCourse.setBounds(80+450,95+50,90,60);
		this.add(jcbUpdateCName);
		jcbUpdateCName.setBounds(620, 110+50, 100, 30);
		this.add(jtUpdateCourseXS);
		jtUpdateCourseXS.setBounds(721,110+50,60+5,30);
		this.add(jtUpdateCourseXF);
		jtUpdateCourseXF.setBounds(782+5, 110+50, 60+5, 30);
		this.add(jbUpdateCourse);
		jbUpdateCourse.setBounds(845+5+5, 110+50, 60, 30);
		
		this.add(jlAddCourse);
		jlAddCourse.setBounds(80+450,155+50,90,60);
		this.add(jtAddCourseName);
		jtAddCourseName.setBounds(620, 170+50, 100, 30);
		this.add(jtAddCourseXS);
		jtAddCourseXS.setBounds(721, 170+50, 60+5, 30);
		this.add(jtAddCourseXF);
		jtAddCourseXF.setBounds(782+5, 170+50, 60+5, 30);
		this.add(jbAdd);
		jbAdd.setBounds(845+5+5, 170+50, 60, 30);
		
		
		this.setBounds(0,0, 992, 590);
		this.setVisible(true);
		this.setBorder(BorderFactory.createLineBorder(Color.black));
		this.setBackground(null);                      // �ѱ�������Ϊ��  
		this.setOpaque(false);   
	}
	
	
	//�Զ����ı��򽹵������
	class MyFocusListener implements FocusListener {
	    String info;
	    JTextField jtf;
	    public MyFocusListener(String info, JTextField jtf) {
	        this.info = info;
	        this.jtf = jtf;
	    }
	    @Override
	    public void focusGained(FocusEvent e) {//��ý����ʱ��,�����ʾ����
	        String temp = jtf.getText();
	        if(temp.equals(info)){
	            jtf.setText("");
	            jtf.setForeground(Color.black);
	        }
	    }
	    @Override
	    public void focusLost(FocusEvent e) {//ʧȥ�����ʱ��,�ж����Ϊ��,����ʾ��ʾ����
	        String temp = jtf.getText();
	        if(temp.equals("")){
	            jtf.setText(info);
	            jtf.setForeground(Color.lightGray);
	        }else{
	        	jtf.setForeground(Color.black);
	        }
	    }
	}	
}
