package student.main;
/**
 * ��ʦѧ���������
 */
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import bean.Score;
import bean.Student;
import db.MysqlConn;
import db.MysqlConn.SelectListener;
import util.FrameToumingPanelUtil;

public class TeacherStudentPanel extends JPanel{
	private JLabel jlName,jlSex,jlBirthday,jlPhoto,jlKc;
	private JTextField jtName,jtBirthday,jtPhoto,jtKc;
	private ButtonGroup jbgSex;
	private JRadioButton jrBoy,jrGirl;
	private JButton jbLookPhoto,jbAdd,jbDelete,jbUpdate,jbReserch;
	private Font font;
	private JLabel jpPhoto;
	String[] field={"����","����"};
	Object[][] data={{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},
			{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",}};
	private DefaultTableModel mod;
	private JTable tab;
	private JScrollPane jsp;
	private JFileChooser chooser;
	
	public TeacherStudentPanel(){
		font=new Font("����",Font.BOLD,16);
		this.setLayout(null);
		mod=new DefaultTableModel(data,field);
		
		tab=new JTable(mod);
		jsp=new JScrollPane();
		jsp.getViewport().add(tab);
		tab.setEnabled(false);

		
		jpPhoto=new JLabel();
		
		jlName=new JLabel("�� ����");
		jlName.setFont(font);
		jlSex=new JLabel("�� ��");
		jlSex.setFont(font);
		jlBirthday=new JLabel("��������:");
		jlBirthday.setFont(font);

		jlPhoto=new JLabel("�� Ƭ:");
		jlPhoto.setFont(font);
		jlKc=new JLabel("���޿γ�");
		jlKc.setFont(font);
		jtName=new JTextField();
		jtBirthday=new JTextField("��ʽΪ:2017-01-01");
		jtBirthday.setForeground(Color.lightGray);
		jtBirthday.addFocusListener(new MyFocusListener("��ʽΪ:2017-01-01", jtBirthday));
		jtPhoto=new JTextField();
		jtKc=new JTextField();
		jbgSex=new ButtonGroup();	
		jrBoy=new JRadioButton("��");
		jrBoy.setFont(font);
		jrGirl=new JRadioButton("Ů");
		jrGirl.setFont(font);
		jrBoy.setBackground(null);                      // �ѱ�������Ϊ��  
		jrBoy.setOpaque(false);
		jrBoy.setForeground(Color.white);
		jrGirl.setBackground(null);                      // �ѱ�������Ϊ��  
		jrGirl.setOpaque(false);
		jrGirl.setForeground(Color.white);
		jrGirl.setFont(font);
		jbgSex.add(jrBoy);
		jbgSex.add(jrGirl);
		
		jbLookPhoto=new JButton("���...");	
		jbLookPhoto.setFont(font);
		chooser = new JFileChooser();
        chooser.setCurrentDirectory(new File("."));    
		jbLookPhoto.addActionListener(new ActionListener() {     
        	@Override
         	public void actionPerformed(ActionEvent arg0) { 
        		 int result = chooser.showOpenDialog(null);
        	        String name = null;
					try {
						name = chooser.getSelectedFile().getCanonicalPath();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
        	        ImageIcon ii=new ImageIcon(name);
                 if(result == JFileChooser.APPROVE_OPTION){                     
                     jtPhoto.setText(name);                     
                     ii.setImage(ii.getImage().getScaledInstance(120, 160,  
                             Image.SCALE_DEFAULT)); 
                     jpPhoto.setIcon(ii);
                 }
             }
         }); 
		
		jbAdd=new JButton("¼��");
		jbAdd.setFont(font);
		jbAdd.addActionListener(new ActionListener() {	
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!jtName.getText().toString().equals("")&&!jtBirthday.getText().toString().equals("")
						&&!jtPhoto.getText().toString().equals("")&&(jrBoy.isSelected()||jrGirl.isSelected())) {
					String s=jtBirthday.getText();
					if(!s.matches("\\d{4}[-]\\d{1,2}[-]\\d{1,2}")) {
						JOptionPane.showMessageDialog(null,"���ڸ�ʽ�����硰2015-02-01��","����",JOptionPane.ERROR_MESSAGE);
					}else {
						
						String[] s1=s.split("-");
						int year=Integer.parseInt(s1[0])-1900;
						int month=Integer.parseInt(s1[1])-1;
						int day=Integer.parseInt(s1[2]);
						Student stu=null;
						boolean isSuccess = false;
						if(jrBoy.isSelected()) {
							isSuccess=MysqlConn.addStudent(new Student(jtName.getText().toString(),"��",new java.sql.Date(year,month,day),jtPhoto.getText().toString()));						
						}else {
							isSuccess=MysqlConn.addStudent(new Student(jtName.getText().toString(),"Ů",new java.sql.Date(year,month,day),jtPhoto.getText().toString()));
						}	
						if(isSuccess) {
							JOptionPane.showMessageDialog(null, "¼��ɹ�������","",JOptionPane.INFORMATION_MESSAGE);
							jtBirthday.setText("");
							jtPhoto.setText("");
							jtName.setText("");
							jtKc.setText("");
							jrBoy.setSelected(false);
							jrGirl.setSelected(false);
							while(mod.getRowCount()>0) {
								mod.removeRow(0);
							}
							if(mod.getRowCount()<40){
								for(int i=0;i<40-mod.getRowCount();i++){
									mod.addRow(new Object[] {,});
								}
							}
							ImageIcon i=new ImageIcon("img/z.png");
							i.setImage(i.getImage().getScaledInstance(120, 160,  
		                             Image.SCALE_DEFAULT)); 
		                    jpPhoto.setIcon(i);
						}else {
							JOptionPane.showMessageDialog(null,"¼��ʧ��,�Ѵ���","����",JOptionPane.ERROR_MESSAGE);
						}
					}
					
				}else{
					JOptionPane.showMessageDialog(null, "¼��ʧ�ܣ��밴Ҫ������������Ϣ������","����",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		
		jbDelete=new JButton("ɾ��");
		jbDelete.setFont(font);
		jbDelete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(MysqlConn.selectStudent(jtName.getText().toString())) {
					if(!MysqlConn.selectStudentScore(jtName.toString())){					
						boolean isSuccess=false;
						isSuccess=MysqlConn.deleteStudent(jtName.getText().toString());
						if(isSuccess){
							JOptionPane.showMessageDialog(null, "ɾ���ɹ�������","",JOptionPane.INFORMATION_MESSAGE);
							jtName.setText("");
						}
					}else{
						JOptionPane.showMessageDialog(null,"ɾ��ʧ��,��ѧ���гɼ���¼��","����",JOptionPane.ERROR_MESSAGE);
						jtBirthday.setText("");
						jtPhoto.setText("");
						jtName.setText("");
						jtKc.setText("");
						jrBoy.setSelected(false);
						jrGirl.setSelected(false);
						while(mod.getRowCount()>0) {
							mod.removeRow(0);
						}
						if(mod.getRowCount()<40){
							for(int i=0;i<40-mod.getRowCount();i++){
								mod.addRow(new Object[] {,});
							}
						}
						
					}
					
				}else {
					JOptionPane.showMessageDialog(null,"ɾ��ʧ��,û�и�ѧ����¼��","����",JOptionPane.ERROR_MESSAGE);
					jtName.setText("");
				}
			}
		});
		
		jbUpdate=new JButton("����");
		jbUpdate.setFont(font);
		jbUpdate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				boolean isSuccess=false;
				String s=jtBirthday.getText();
				if(!s.matches("\\d{4}[-]\\d{1,2}[-]\\d{1,2}")) {
					JOptionPane.showMessageDialog(null,"������������Ϣ�������ڸ�ʽ�硰2015-02-01��","����",JOptionPane.ERROR_MESSAGE);
				}else {
					String[] s1=s.split("-");
					int year=Integer.parseInt(s1[0])-1900;
					int month=Integer.parseInt(s1[1])-1;
					int day=Integer.parseInt(s1[2]);
					if(jrBoy.isSelected()) {
						isSuccess=MysqlConn.updateStudent(new Student(jtName.getText().toString(),"��",new java.sql.Date(year,month,day),jtPhoto.getText().toString()));						
					}else {
						isSuccess=MysqlConn.updateStudent(new Student(jtName.getText().toString(),"Ů",new java.sql.Date(year,month,day),jtPhoto.getText().toString()));
					}
					if(isSuccess) {
						JOptionPane.showMessageDialog(null, "���³ɹ�������","",JOptionPane.INFORMATION_MESSAGE);
						jtBirthday.setText("");
						jtPhoto.setText("");
						jtName.setText("");
						jtKc.setText("");
						jrBoy.setSelected(false);
						jrGirl.setSelected(false);
						while(mod.getRowCount()>0) {
							mod.removeRow(0);
						}
						if(mod.getRowCount()<40){
							for(int i=0;i<40-mod.getRowCount();i++){
								mod.addRow(new Object[] {,});
							}
						}
						ImageIcon i=new ImageIcon("img/z.png");
						i.setImage(i.getImage().getScaledInstance(120, 160,  
	                             Image.SCALE_DEFAULT)); 
	                    jpPhoto.setIcon(i);
					}else {
						JOptionPane.showMessageDialog(null,"����ʧ��,��ѧ��������","����",JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});
		jbReserch=new JButton("��ѯ");
		jbReserch.setFont(font);
		jbReserch.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(MysqlConn.selectStudent(jtName.getText().toString())) {
					
					MysqlConn.selectStudent(jtName.getText().toString(), new SelectListener() {					
						@Override
						public void complete(List<Score> list, Student stu) {
							if(stu.getXB().toString().equals("��")) {
								while(mod.getRowCount()>0) {
									mod.removeRow(0);
								}
								jrBoy.setSelected(true);
								jrGirl.setSelected(false);
								jtBirthday.setText(stu.getCssj().toString());
								jtPhoto.setText(stu.getZp());
								jtKc.setText("\t"+stu.getKcs());
								ImageIcon i=new ImageIcon(stu.getZp().toString());
								i.setImage(i.getImage().getScaledInstance(120, 160,  
										Image.SCALE_DEFAULT)); 
								jpPhoto.setIcon(i);
								for(int j=0;j<list.size();j++) {
									mod.addRow(new Object[] {list.get(j).getKcm(),list.get(j).getCj()});
								}
								if(mod.getRowCount()<40){
									for(int n=0;n<40-mod.getRowCount();n++){
										mod.addRow(new Object[] {,});
									}
								}
								
							}else {
								jrBoy.setSelected(false);
								jrGirl.setSelected(true);
								jtBirthday.setText(stu.getCssj().toString());
								jtPhoto.setText(stu.getZp());
								ImageIcon i=new ImageIcon(stu.getZp().toString());
								i.setImage(i.getImage().getScaledInstance(120, 160,  
										Image.SCALE_DEFAULT)); 
								jpPhoto.setIcon(i);
							}
							
						}

						@Override
						public void toList(List list) {}
					});
				}else {
					JOptionPane.showMessageDialog(null,"��ѯʧ��,��ѧ��������","����",JOptionPane.ERROR_MESSAGE);
					jtBirthday.setText("");
					jtPhoto.setText("");
					jtName.setText("");
					jtKc.setText("");
					jrBoy.setSelected(false);
					jrGirl.setSelected(false);
					while(mod.getRowCount()>0) {
						mod.removeRow(0);
					}
					if(mod.getRowCount()<40){
						for(int i=0;i<40-mod.getRowCount();i++){
							mod.addRow(new Object[] {,});
						}
					}
		
				}
					
				
			}
		});
		
		this.add(jlName);
		jlName.setBounds(80, 35, 60, 60);
		this.add(jtName);
		jtName.setBounds(170, 50, 170, 30);
		this.add(jlKc);
		jlKc.setBounds(550, 35, 80, 60);
		this.add(jtKc);
		jtKc.setEnabled(false);
		jtKc.setCaretColor(Color.red);
		jtKc.setFont(new Font("����",Font.PLAIN,30));
		jtKc.setBounds(635, 50, 300, 30);
		jtPhoto.setEnabled(false);
		this.add(jsp);
		jsp.setBounds(550, 100, 400, 330);
		this.add(jlSex);
		jlSex.setBounds(80, 95, 60, 60);
		this.add(jrBoy);
		jrBoy.setBounds(170, 95, 50, 60);
		this.add(jrGirl);
		jrGirl.setBounds(220, 95, 50, 60);
		this.add(jlBirthday);
		jlBirthday.setBounds(80, 155, 80, 60);
		this.add(jtBirthday);
		jtBirthday.setBounds(170, 170, 170, 30);
		this.add(jlPhoto);
		jlPhoto.setBounds(80, 215, 80, 60);
		this.add(jtPhoto);
		jtPhoto.setBounds(170, 230, 170, 30);
		this.add(jbLookPhoto);
		jbLookPhoto.setBounds(340, 230, 100, 30);
		this.add(jpPhoto);
		jpPhoto.setBounds(170, 270, 120, 160);
		this.add(jbAdd);
		jbAdd.setBounds(170, 485, 110, 40);
		this.add(jbDelete);
		jbDelete.setBounds(330, 485, 110, 40);
		this.add(jbUpdate);
		jbUpdate.setBounds(490, 485, 110, 40);
		this.add(jbReserch);
		jbReserch.setBounds(650, 485, 110, 40);

		
		this.setBackground(Color.pink);
		this.setBounds(0,0, 992, 590);
		this.setVisible(true);
		this.setBorder(BorderFactory.createLineBorder(Color.black));
		this.setBackground(null);                      // �ѱ�������Ϊ��  
		this.setOpaque(false);   
	}
	//�Զ����ı��򽹵������
		class MyFocusListener implements FocusListener {
		    String info;
		    JTextField jtf;
		    public MyFocusListener(String info, JTextField jtf) {
		        this.info = info;
		        this.jtf = jtf;
		    }
		    @Override
		    public void focusGained(FocusEvent e) {//��ý����ʱ��,�����ʾ����
		        String temp = jtf.getText();
		        if(temp.equals(info)){
		            jtf.setText("");
		            jtf.setForeground(Color.black);
		        }
		    }
		    @Override
		    public void focusLost(FocusEvent e) {//ʧȥ�����ʱ��,�ж����Ϊ��,����ʾ��ʾ����
		        String temp = jtf.getText();
		        if(temp.equals("")){
		            jtf.setText(info);
		            jtf.setForeground(Color.lightGray);
		        }else{
		        	jtf.setForeground(Color.black);
		        }
		    }
		}
}
