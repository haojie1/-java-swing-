package student.main;
/**
 * 学生主界面
 */
import javax.swing.*;

import util.FrameShowCenterUtil;
import util.FrameToumingPanelUtil;
import util.HomePanelUtil;

import java.awt.*;
import java.awt.event.*;

public class StudentMain extends JFrame implements ActionListener{
	private FrameToumingPanelUtil jpHead,jpLeft,jpMain;
	private JPanel jpFoot;
	private JLabel jlHead,jlFoot;
	private JButton jbStudent,jbCancel;
	private Container con;
	private BorderLayout bor;
	public String xsxh=null;

	public StudentMain(String xushengzhanghao){
		super("软件二班学生成绩系统");
		xsxh=xushengzhanghao;
		bor=new BorderLayout();
		jpHead=new FrameToumingPanelUtil();
		jpLeft=new FrameToumingPanelUtil();
		jpMain=new FrameToumingPanelUtil();
		jpFoot=new JPanel();
		jlHead=new JLabel("学生成绩管理系统");
		jlFoot=new JLabel("Copright©2017  湖南工业大学软件工程1502班汪恒 .All right reserved");
		jbStudent=new JButton("信息查询");
		jbCancel=new JButton("退   出");
		con=this.getContentPane();
		con.setLayout(null);
		HomePanelUtil hpMain=new HomePanelUtil("img/timg.jpg",1200,800);
		con.add(hpMain);
	
		jpHead.setLayout(null);
		jpHead.add(jlHead);
		jlHead.setBounds(250, 35, 800, 90);
		jlHead.setFont(new Font("宋体",Font.BOLD,85)); 
		hpMain.add(jpHead);
		jpHead.setBounds(0, 0, 1194, 150);
		jpHead.setBorder(BorderFactory.createLineBorder(Color.black));
		
		jpLeft.setLayout(null);
		jpLeft.add(jbStudent);
		jbStudent.setBounds(45, 120, 110, 40);
		jbStudent.setFont(new Font("宋体",Font.BOLD,16));

		jpLeft.add(jbCancel);
		jbCancel.setBounds(45, 400, 110, 40);
		jbCancel.setFont(new Font("宋体",Font.BOLD,16));
		hpMain.add(jpLeft);
		jpLeft.setBounds(0, 152, 200, 590);
		jpLeft.setBorder(BorderFactory.createLineBorder(Color.black));
		
		hpMain.add(jpMain);
		jpMain.setBounds(202, 152, 992, 590);
		jpMain.setBorder(BorderFactory.createLineBorder(Color.black));
		jpFoot.add(jlFoot);
		jlFoot.setFont(new Font("宋体",Font.BOLD,16));
		hpMain.add(jpFoot);
		jpFoot.setBackground(null);                      // 把背景设置为会  
		jpFoot.setOpaque(false);     
		jpFoot.setBounds(0, 741, 1194, 52);
		jpFoot.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		jbStudent.addActionListener(this);
		jbCancel.addActionListener(this);
		
		FrameShowCenterUtil.showCenter(this, 1200, 800);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==jbStudent){
			jpMain.removeAll();
			StudentQueryPanel p=new StudentQueryPanel(xsxh);
			jpMain.setLayout(null);
			jpMain.add(p);			
			this.repaint();
			this.validate();
		}
		if(e.getSource()==jbCancel){
			this.dispose();
			new Login();
		}
	}
}