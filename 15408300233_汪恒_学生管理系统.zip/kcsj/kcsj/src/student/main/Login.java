package student.main;
/**
 * ��¼����
 */
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import gn.SignIn;
import util.FrameShowCenterUtil;


import java.awt.*;
import java.awt.event.*;

public class Login extends JFrame implements DocumentListener{
	SignIn si=new SignIn();
	public Login(){
		ImageIcon ii=new ImageIcon("img/bj.jpg");
		JLabel jl=new JLabel(ii,JLabel.CENTER);
		jl.add(si);
		si.setBounds(348, 250, 384, 200);
		si.setBackground(Color.gray);		
		this.getContentPane().add(jl);		
    	FrameShowCenterUtil.showCenter(this, ii.getIconWidth(),ii.getIconHeight()+28);		
    	si.jt.getDocument().addDocumentListener(this);
    	 	
	}
	public static void main(String[] args) {
		Login si=new Login();
	}

	@Override
	public void insertUpdate(DocumentEvent e) {
		if(si.jt.getText().equals("ͨ��")){
			this.dispose();
		}
	}
	public void removeUpdate(DocumentEvent e) {}
	public void changedUpdate(DocumentEvent e) {}	
}
