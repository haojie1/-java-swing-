package student.main;
/**
 * ѧ����ѯ��Ϣ���
 */
import java.awt.*;
import java.awt.event.*;
import java.util.List;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import bean.Score;
import bean.Student;
import db.MysqlConn;
import db.MysqlConn.SelectListener;
import util.FrameToumingPanelUtil;

public class StudentQueryPanel extends JPanel{
	private JLabel jlName,jlSex,jlBirthday,jlPhoto,jlKc;
	private JTextField jtName,jtBirthday,jtPhoto,jtKc;
	private ButtonGroup jbgSex;
	private JRadioButton jrBoy,jrGirl;
	private Font font;
	private JLabel jpPhoto;
	String[] field={"�γ���","����"};
	Object[][] data={{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},
			{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",}};
	private DefaultTableModel mod;
	private JTable tab;
	private JScrollPane jsp;
	
	public StudentQueryPanel(String xszh){
		
		font=new Font("����",Font.BOLD,16);
		this.setLayout(null);
		mod=new DefaultTableModel(data,field);
		tab=new JTable(mod);
		tab.setBackground(null);                      // �ѱ�������Ϊ��  
		tab.setOpaque(false);
		jsp=new JScrollPane();
		jsp.getViewport().add(tab);
		tab.setEnabled(false);
		
		jpPhoto=new JLabel();
		jpPhoto.setBackground(Color.gray);
		jlName=new JLabel("�� ����");
		jlName.setFont(font);
		jlName.setForeground(Color.white);
		jlSex=new JLabel("�� ��");
		jlSex.setForeground(Color.white);
		jlSex.setFont(font);
		jlBirthday=new JLabel("��������:");
		jlBirthday.setForeground(Color.white);
		jlBirthday.setFont(font);
		jlPhoto=new JLabel("�� Ƭ:");
		jlPhoto.setForeground(Color.white);
		jlPhoto.setFont(font);
		jlKc=new JLabel("���޿γ�");
		jlKc.setForeground(Color.white);
		jlKc.setFont(font);
		jtName=new JTextField();
		jtBirthday=new JTextField();
		jtPhoto=new JTextField();
		jtKc=new JTextField();
		jbgSex=new ButtonGroup();	
		jrBoy=new JRadioButton("��");
		jrBoy.setFont(font);
		jrBoy.setEnabled(false);
		jrBoy.setForeground(Color.white);
		jrGirl=new JRadioButton("Ů");
		jrGirl.setForeground(Color.white);
		jrGirl.setEnabled(false);
		jrBoy.setBackground(null);                      // �ѱ�������Ϊ��  
		jrBoy.setOpaque(false);
		jrBoy.setForeground(Color.white);
		jrGirl.setBackground(null);                      // �ѱ�������Ϊ��  
		jrGirl.setOpaque(false);
		jrGirl.setForeground(Color.white);
		jrGirl.setFont(font);
		jbgSex.add(jrBoy);
		jbgSex.add(jrGirl);

		this.add(jpPhoto);
		jpPhoto.setBounds(175, 60+50, 155, 170);
		jpPhoto.setBackground(Color.gray);
		this.add(jlName);
		jlName.setBounds(80, 285, 60, 60);
		this.add(jtName);
		jtName.setBounds(170, 300, 170, 30);
		jtName.setEnabled(false);
		jtName.setFont(new Font("����",Font.PLAIN,20));
		this.add(jlKc);
		jlKc.setBounds(550, 85, 80, 60);
		this.add(jtKc);
		jtKc.setBackground(Color.gray);
		jtKc.setEnabled(false);
		jtKc.setBounds(635, 100, 300, 30);
		this.add(jsp);
		jsp.setBounds(550, 150, 400, 330);
		this.add(jlSex);
		jlSex.setBounds(80, 345, 60, 60);
		this.add(jrBoy);
		jrBoy.setBounds(170, 345, 50, 60);
		this.add(jrGirl);
		jrGirl.setBounds(220, 345, 50, 60);
		this.add(jlBirthday);
		jlBirthday.setBounds(80, 405, 80, 60);
		this.add(jtBirthday);
		jtBirthday.setBounds(170, 420, 170, 30);
		jtBirthday.setEnabled(false);
		jtBirthday.setFont(new Font("����",Font.PLAIN,20));
		this.add(jlPhoto);
		jlPhoto.setBounds(80, 90, 80, 60);
		jtKc.setCaretColor(Color.red);
		jtKc.setFont(new Font("����",Font.PLAIN,30));
		
		MysqlConn.selectStudent(xszh, new SelectListener() {		
			@Override
			public void toList(List<Score> list) {}		
			@Override
			public void complete(List<Score> list, Student stu) {
				if(stu.getXB().toString().equals("��")) {
					while(mod.getRowCount()>0) {
						mod.removeRow(0);
					}
					jtName.setText(xszh);
					jrBoy.setSelected(true);
					jrGirl.setSelected(false);
					jtBirthday.setText(stu.getCssj().toString());
					jtPhoto.setText(stu.getZp());
					jtKc.setText("\t"+stu.getKcs());
					ImageIcon i=new ImageIcon(stu.getZp().toString());
					i.setImage(i.getImage().getScaledInstance(120, 160,  
							Image.SCALE_DEFAULT)); 
					jpPhoto.setIcon(i);
					for(int j=0;j<list.size();j++) {
						mod.addRow(new Object[] {list.get(j).getKcm(),list.get(j).getCj()});
					}
					
				}else {
					jrBoy.setSelected(false);
					jrGirl.setSelected(true);
					jtBirthday.setText(stu.getCssj().toString());
					jtPhoto.setText(stu.getZp());
					ImageIcon i=new ImageIcon(stu.getZp().toString());
					i.setImage(i.getImage().getScaledInstance(120, 160,  
							Image.SCALE_DEFAULT)); 
					jpPhoto.setIcon(i);
				}

				
			}
		});
		//this.setBackground(Color.white);
		this.setBounds(0,0, 992, 590);
		this.setVisible(true);
		this.setBorder(BorderFactory.createLineBorder(Color.black));
		this.setBackground(null);                      // �ѱ�������Ϊ��  
		this.setOpaque(false);   
		
	}
}
