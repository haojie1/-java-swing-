package student.main;
/**
 * ��ʦ�ɼ��������
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import bean.Score;
import bean.Student;
import db.MysqlConn;
import db.MysqlConn.SelectListener;
import util.FrameToumingPanelUtil;

import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class TeacherScorePanel extends JPanel{
	private JLabel jlCname,jlName,jlScore;
	private JComboBox jcbCname;
	private JTextField jtName,jtScore;
	private JButton jbReserch,jbAdd,jbDelete;
	String[] score=null;
	String[] field={"����","�ɼ�"};
	Object[][] data={{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},
			{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",},{"",}};
	private DefaultTableModel mod;
	private JTable tab;
	private JScrollPane jsp;
	private Font font;
	private JLabel jp;
	
	public TeacherScorePanel(){
		font=new Font("����",Font.BOLD,16);
		this.setLayout(null);
		mod=new DefaultTableModel(data,field);
		tab=new JTable(mod);
		tab.setBackground(null);                      // �ѱ�������Ϊ��  
		tab.setOpaque(false);
		jsp=new JScrollPane();
		jsp.getViewport().add(tab);
		tab.setEnabled(false);
		
		jp=new JLabel();
		jlCname=new JLabel("�γ�����");
		jlCname.setFont(font);
		jlName=new JLabel("�� ����");
		jlName.setFont(font);
		jlScore=new JLabel("�� ����");
		jlScore.setFont(font);
		score = MysqlConn.selectKcm();
		jcbCname=new JComboBox(score);
		jcbCname.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				MysqlConn.selectScore(jcbCname.getSelectedItem().toString(), new SelectListener() {					
					@Override
					public void toList(List<Score> list) {
						while(mod.getRowCount()>0) {
							mod.removeRow(0);
						}
						for(int j=0;j<list.size();j++) {
							mod.addRow(new Object[] {list.get(j).getXm(),list.get(j).getCj()});
						}
						if(mod.getRowCount()<40){
							for(int i=0;i<40-mod.getRowCount();i++){
								mod.addRow(new Object[] {,});
							}
						}
					}					
					@Override
					public void complete(List<Score> list, Student stu) {}
				});
				
			}
		});;
		
		jtName=new JTextField();
		jtScore=new JTextField();
		
		jbReserch=new JButton("��ѯ");
		jbReserch.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				MysqlConn.selectScore(jcbCname.getSelectedItem().toString(), new SelectListener() {					
					@Override
					public void toList(List<Score> list) {
						while(mod.getRowCount()>0) {
							mod.removeRow(0);
						}
						for(int j=0;j<list.size();j++) {
							mod.addRow(new Object[] {list.get(j).getXm(),list.get(j).getCj()});
						}
						if(mod.getRowCount()<40){
							for(int i=0;i<40-mod.getRowCount();i++){
								mod.addRow(new Object[] {,});
							}
						}
					}					
					@Override
					public void complete(List<Score> list, Student stu) {}
				});
				
			}
		});
		jbAdd=new JButton("¼��");
		jbAdd.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				try{				
					if(jtName.getText().toString().equals("")||jtScore.getText().toString().equals("")) {
						JOptionPane.showMessageDialog(null,"¼��ʧ��,����д������Ϣ","����",JOptionPane.ERROR_MESSAGE);
					}else if(!MysqlConn.selectStudent(jtName.getText().toString())){
						JOptionPane.showMessageDialog(null,"¼��ʧ��,�����ڸ�ѧ��","����",JOptionPane.ERROR_MESSAGE);
						jtName.setText("");
					}else if(Integer.valueOf(jtScore.getText().toString())>100||Integer.valueOf(jtScore.getText().toString())<0){
						JOptionPane.showMessageDialog(null,"¼��ʧ��,����Ӧ��0-100֮��","����",JOptionPane.ERROR_MESSAGE);
						jtScore.setText("");
					}else if(!MysqlConn.selectScore(jcbCname.getSelectedItem().toString(), jtName.getText().toString(), jtScore.getText())){
						boolean isSuccess=false;
						isSuccess=MysqlConn.addScore(jcbCname.getSelectedItem().toString(), jtName.getText().toString(), jtScore.getText().toString());
						if(isSuccess==true) { 	
							MysqlConn.selectScore(jcbCname.getSelectedItem().toString(), new SelectListener() {					
								@Override
								public void toList(List<Score> list) {
									while(mod.getRowCount()>0) {
										mod.removeRow(0);
									}
									for(int j=0;j<list.size();j++) {
										mod.addRow(new Object[] {list.get(j).getXm(),list.get(j).getCj()});
									}	
									if(mod.getRowCount()<40){
										for(int i=0;i<40-mod.getRowCount();i++){
											mod.addRow(new Object[] {,});
										}
									}
								}					
								@Override
								public void complete(List<Score> list, Student stu) {}
							});
							//jtName.setText("");
							jtScore.setText("");
						}
					}else{
						JOptionPane.showMessageDialog(null,"¼��ʧ��,�óɼ��Ѿ�ӵ��","����",JOptionPane.ERROR_MESSAGE);
						
						jtScore.setText("");
					}
				}catch(Exception e1){
					JOptionPane.showMessageDialog(null,"¼��ʧ��,��������ȷ����","����",JOptionPane.ERROR_MESSAGE);
					jtScore.setText("");
				}
				
			}
		});
		jbDelete=new JButton("ɾ��");
		jbDelete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(jtName.getText().toString().equals("")) {
					JOptionPane.showMessageDialog(null,"ɾ��ʧ��,����������","����",JOptionPane.ERROR_MESSAGE);
				}else if(!MysqlConn.selectStudent(jtName.getText().toString())){
					JOptionPane.showMessageDialog(null,"ɾ��ʧ��,�����ڸ�ѧ��","����",JOptionPane.ERROR_MESSAGE);
				}else if(MysqlConn.selectScore(jcbCname.getSelectedItem().toString(), jtName.getText().toString(), jtScore.getText())){
					boolean isSuccess=false;
					isSuccess=MysqlConn.deleteScore(jcbCname.getSelectedItem().toString(), jtName.getText().toString());
					if(isSuccess==true) { 	
						MysqlConn.selectScore(jcbCname.getSelectedItem().toString(), new SelectListener() {					
							@Override
							public void toList(List<Score> list) {
								while(mod.getRowCount()>0) {
									mod.removeRow(0);
								}
								for(int j=0;j<list.size();j++) {
									mod.addRow(new Object[] {list.get(j).getXm(),list.get(j).getCj()});
								}	
								if(mod.getRowCount()<40){
									for(int i=0;i<40-mod.getRowCount();i++){
										mod.addRow(new Object[] {,});
									}
								}
							}					
							@Override
							public void complete(List<Score> list, Student stu) {}
						});
						jtName.setText("");
						jtScore.setText("");
					}else {
						JOptionPane.showMessageDialog(null,"ɾ��ʧ��","����",JOptionPane.ERROR_MESSAGE);
						jtScore.setText("");
					}
				}
				
			}
		});
		
		this.add(jlCname);
		jlCname.setBounds(280, 35, 80, 60);
		this.add(jcbCname);
		jcbCname.setBounds(370, 50, 170, 30);
		this.add(jbReserch);
		jbReserch.setBounds(542, 50, 60, 30);
		this.add(jlName);
		jlName.setBounds(280,95,80,60);
		this.add(jtName);
		jtName.setBounds(370,110,170,30);
		this.add(jlScore);
		jlScore.setBounds(280,155,80,60);
		this.add(jtScore);
		jtScore.setBounds(370,170,170,30);
		this.add(jbAdd);
		jbAdd.setBounds(542, 170, 60, 30);
		this.add(jbDelete);
		jbDelete.setBounds(604, 170, 60, 30);
		this.add(jsp);
		jsp.setBounds(280, 230, 385, 275);

		this.setBounds(0,0, 992, 590);
		this.setVisible(true);
		this.setBorder(BorderFactory.createLineBorder(Color.black));
		this.setBackground(null);                      // �ѱ�������Ϊ��  
		this.setOpaque(false);   
	}
}
