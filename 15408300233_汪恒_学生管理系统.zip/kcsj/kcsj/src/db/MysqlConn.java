package db;
/**
 * jdbc������
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import bean.Course;
import bean.Score;
import bean.Student;

public class MysqlConn {
	public static Connection conns;
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conns=DriverManager.getConnection("jdbc:mysql://localhost:3306/xsxx?useUnicode=true&characterEncoding=utf8","root","123456");	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * ��֤�û�
	 * @param stuname
	 * @param stupwd
	 * @return
	 */
	public static boolean isUser(String stuname,String stupwd){	
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		int flag=0;
		try{			
	        String strsql="select * from zhanghaomima where zhanghao=? and mima=?";
	        pstmt=conns.prepareStatement(strsql);
	        pstmt.setString(1, stuname);
	        pstmt.setString(2, stupwd);
	        rs=pstmt.executeQuery();
	        while(rs.next()){
	        	flag++;
	        }
	        if(flag==0)		
	        	return false;

		}catch(SQLException e){
			e.printStackTrace();
			return false;
		}finally{
			try{
	        	rs.close();
	        }catch(SQLException e){	}	 
	        
	        try{
	        	pstmt.close();
	        }catch(SQLException e){	}	           
		}
		return true;
	}
	
	/**
	 * ¼��ѧ��
	 */
	public static boolean addStudent(Student student){
		PreparedStatement pstmt=null;
		String sql="insert into XS(xm,xb,cssj,zp,kcs)values(?,?,?,?,?);";
		String sql2="insert into zhanghaomima(zhanghao,mima)values(?,?);";
		try {
			pstmt=MysqlConn.conns.prepareStatement(sql);			
			pstmt.setString(1, student.getXm());
			pstmt.setString(2, student.getXB());
			pstmt.setTimestamp(3, new Timestamp(student.getCssj().getTime()));
			pstmt.setString(4, student.getZp());
			pstmt.setInt(5, 0);
			pstmt.execute();
			
			pstmt=MysqlConn.conns.prepareStatement(sql2);
			pstmt.setString(1, student.getXm());
			pstmt.setString(2, "123456");
			pstmt.execute();
		} catch (SQLException e) {
			return false;
		}finally{
	        try{
	        	pstmt.close();
	        }catch(SQLException e){	}	           
		}		
		return true;
	}
	
	/**
	 * ɾ��ѧ��
	 */
	public static boolean deleteStudent(String name){
		PreparedStatement pstmt=null;
		String sql="delete from xs where xm=?;";
		String sql2="delete from zhanghaomima where zhanghao=?;";
		try {
			pstmt=MysqlConn.conns.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.execute();
			
			pstmt=MysqlConn.conns.prepareStatement(sql2);
			pstmt.setString(1, name);
			pstmt.execute();
		} catch (SQLException e) {
			return false;
		}finally{
	        try{
	        	pstmt.close();
	        }catch(SQLException e){	}	           
		}
		return true;
	}
	
	/**
	 * �����޸�ѧ����Ϣ
	 */
	public static boolean updateStudent(Student student){
		PreparedStatement pstmt=null;

		String sql="update xs set xb=?,cssj=?,zp=?where xm=?;";
		try {
			pstmt=MysqlConn.conns.prepareStatement(sql);			
			pstmt.setString(1, student.getXB());
			pstmt.setTimestamp(2, new Timestamp(student.getCssj().getTime()));
			pstmt.setString(3, student.getZp());			
			pstmt.setString(4, student.getXm());
			pstmt.execute();
			
		} catch (SQLException e) {
			return false;
		}finally{
	        try{
	        	pstmt.close();
	        }catch(SQLException e){	}	           
		}
		return true;
	}
	
	/**
	 * ����һ���ӿ�
	 * @author asus
	 *
	 */
	public interface SelectListener{
		void complete(List<Score> list,Student stu);
		void toList(List<Score> list);
	}
	/**
	 * ��ѯѧ����Ϣ
	 */
	public static boolean selectStudent(String name,SelectListener selectListener){
		PreparedStatement pstmt=null;
		ResultSet rsxs=null;
		ResultSet rscj=null;
		Student stu=new Student();
	    List<Score> list= new ArrayList<>();
		int flag=0;
		try{			
	        String sql="select * from xs where xm=?";
	        pstmt=conns.prepareStatement(sql);
	        pstmt.setString(1, name);
	        rsxs=pstmt.executeQuery();
	        while(rsxs.next()){	        	
	        	flag++;
	        	stu.setXB(rsxs.getString("xb").toString());
	        	stu.setKcs(rsxs.getInt("kcs"));
	        	stu.setCssj(rsxs.getDate("cssj"));
	        	stu.setZp(rsxs.getString("zp"));
	        }
	        if(flag==0)		
	        	return false;
	        
	       String sql2="select * from cj where xm=?"; 
	       pstmt=conns.prepareStatement(sql2);
	       pstmt.setString(1, name);
	       rscj=pstmt.executeQuery();
	   
	       Score score=null;
	       while(rscj.next()) {
	    	   score= new Score();
	    	   score.setXm(rscj.getString("xm"));
	    	   score.setKcm(rscj.getString("kcm"));
	    	   score.setCj(rscj.getInt("cj"));
	    	   list.add(score);	       
	       }
	       
		}catch(SQLException e){
			return false;
		}finally{
			try{
	        	rsxs.close();
	        }catch(SQLException e){}	 	        
	        try{
	        	pstmt.close();
	        }catch(SQLException e){}	           
		}
		selectListener.complete(list, stu);
		return true;
		
	}
	
	/**
	 * �ж�ѧ���Ƿ����
	 * @param name
	 * @return
	 */
	public static boolean selectStudent(String name){

		PreparedStatement pstmt=null;
		ResultSet rsxs=null;
		int flag=0;
		try{			
	        String sql="select * from xs where xm=?";
	        pstmt=conns.prepareStatement(sql);
	        pstmt.setString(1, name);
	        rsxs=pstmt.executeQuery();
	        while(rsxs.next()){	        	
	        	flag++;	
	        }
	        if(flag==0)		
	        	return false;	     
	       
		}catch(SQLException e){
			return false;
		}finally{
			try{
	        	rsxs.close();
	        }catch(SQLException e){}	 	        
	        try{
	        	pstmt.close();
	        }catch(SQLException e){}	           
		}
		return true;
		
	}
	
	/**
	 * ��ѯ���пγ�����
	 */
	public static String[] selectKcm() {
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String s[]=null;
		ArrayList<String> str = new ArrayList<>();
		int temp=0;
		  	String sql="select kcm from kc group by kcm";
	        try {
				pstmt=conns.prepareStatement(sql);
				rs=pstmt.executeQuery();
				while(rs.next()){	        	
					str.add(rs.getString("kcm"));
				}
				s = new String[str.size()];
				for(int i=0;i<str.size();i++) {
					s[i] = str.get(i);
				}
				return s;
			} catch (SQLException e) {
			}
	   return null;     
	}
	
	/**
	 * ��ѯ�γ̷�����Ϣ
	 */
	public static boolean selectScore(String kcm,SelectListener selectListener){

		PreparedStatement pstmt=null;
		ResultSet rs=null;
	    List<Score> list= new ArrayList<>();
		int flag=0;
		try{				        	        
	       String sql="select xm,cj from cj where kcm=? group by xm"; 
	       pstmt=conns.prepareStatement(sql);
	       pstmt.setString(1, kcm);
	       rs=pstmt.executeQuery();	   
	       Score score=null;
	       while(rs.next()) {
	    	   score= new Score();
	    	   score.setXm(rs.getString("xm"));	    	 
	    	   score.setCj(rs.getInt("cj"));
	    	   list.add(score);	       
	       }
	       
		}catch(SQLException e){
			return false;
		}finally{			 	        
	        try{
	        	pstmt.close();
	        }catch(SQLException e){}	           
		}
		selectListener.toList(list);
		return true;
		
	}
	
	/**
	 * ��ѯѧ���Ƿ��и��ſγ̳ɼ�
	 */
	public static boolean selectScore(String kcm,String xm,String cj){

		PreparedStatement pstmt=null;
		ResultSet rs=null;
		int flag=0;
		try{				        	        
	       String sql="select * from cj where xm=?  and kcm=? "; 
	       pstmt=conns.prepareStatement(sql);
	       pstmt.setString(1, xm);
	      // pstmt.setString(2, cj);
	       pstmt.setString(2, kcm);
	       rs=pstmt.executeQuery();	   
	       while(rs.next()) {
	    	    flag++;    	    
	       }
	       if(flag==0){
	    	   return false;
	    	   
	       }		
	       
		}catch(SQLException e){
			return false;
		}finally{			 	        
	        try{
	        	pstmt.close();
	        }catch(SQLException e){}	           
		}
		return true;
		
	}
	
	/**
	 * ¼��ɼ�
	 */
	public static boolean addScore(String kcm,String xm,String cj) {
		PreparedStatement pstmt=null;
	       try {
	    	String sql="insert into cj (xm,kcm,cj) values(?,?,?)";
	    	String sql2="update xs set kcs=kcs+1 where xm=?";
			pstmt=conns.prepareStatement(sql);
			pstmt.setString(1, xm);
			pstmt.setString(2, kcm);
			pstmt.setString(3, cj);
			pstmt.execute();	  
			
			pstmt=conns.prepareStatement(sql2);
			pstmt.setString(1, xm);
			pstmt.execute();
			
		} catch (SQLException e) {
			return false;
		}
	       return true;
	}
	
	/**
	 * ɾ���ɼ�
	 */
	public static boolean deleteScore(String kcm,String xm) {
		PreparedStatement pstmt=null;
	       try {
	    	String sql="delete from cj where xm=? and kcm=?"; 
	    	String sql2="update xs set kcs=kcs-1 where xm=?";
			pstmt=conns.prepareStatement(sql);
			pstmt.setString(1, xm);
			pstmt.setString(2, kcm);
			pstmt.execute();
			
			pstmt=conns.prepareStatement(sql2);
			pstmt.setString(1, xm);
			pstmt.execute();
			
		} catch (SQLException e) {
			return false;
		}
	       return true;
	}
	
	/**
	 * ��ѯѧ���Ƿ��и��ſγ̳ɼ�
	 */
	public static boolean selectStudentScore(String xm){

		PreparedStatement pstmt=null;
		ResultSet rs=null;
		int flag=0;
		try{				        	        
	       String sql="select * from cj where xm=? "; 
	       pstmt=conns.prepareStatement(sql);
	       pstmt.setString(1, xm);
	       rs=pstmt.executeQuery();	   
	       while(rs.next()) {
	    	    flag++;    	    
	       }
	       if(flag==0)		
	        	return false;
	       
		}catch(SQLException e){
			return false;
		}finally{			 	        
	        try{
	        	pstmt.close();
	        }catch(SQLException e){}	           
		}
		return true;
		
	}
	
	/**
	 * ��ѯ��ʾ�γ���Ϣ
	 */
	public static List<Course> selectCourse(){

		PreparedStatement pstmt=null;
		ResultSet rs=null;
	    List<Course> list= new ArrayList<>();
		int flag=0;
		try{				        	        
	       String sql="select * from kc "; 
	       pstmt=conns.prepareStatement(sql);
	       rs=pstmt.executeQuery();	
	       
	       Course course=null;
	       while(rs.next()) {
	    	   course= new Course();
	    	   course.setKcm(rs.getString("kcm"));  	 
	    	   course.setXs(rs.getInt("xs"));
	    	   course.setXf(rs.getInt("xf"));
	    	   list.add(course);	       
	       }
	       
		}catch(SQLException e){
			System.out.println("11111111111");
		}finally{			 	        
	        try{
	        	pstmt.close();
	        }catch(SQLException e){}	           
		}
		return list;		
	}
	
	
	
	
	/**
	 * ���ӿγ�
	 */
	public static boolean addCourse(String kcm,String xs,String xf) {
		PreparedStatement pstmt=null;
	       try {
	    	String sql="insert into kc (kcm,xs,xf) values(?,?,?)";
			pstmt=conns.prepareStatement(sql);
			pstmt.setString(1, kcm);
			pstmt.setString(2, xs);
			pstmt.setString(3, xf);
			pstmt.execute();	  				
		} catch (SQLException e) {
			return false;
		}
	       return true;
	}
	
	/**
	 * ɾ���ɼ�
	 */
	public static boolean deleteCourse(String kcm) {
		PreparedStatement pstmt=null;
	       try {
	    	String sql="delete from kc where kcm=?";
	    	String sql2="update xs set kcs=kcs-1 where xm in(select xm from cj where kcm=?)";
	    	String sql3="delete from cj where kcm=?";
			pstmt=conns.prepareStatement(sql);
			pstmt.setString(1, kcm);
			pstmt.execute();
			
			pstmt=conns.prepareStatement(sql2);
			pstmt.setString(1, kcm);
			pstmt.execute();
			
			pstmt=conns.prepareStatement(sql3);
			pstmt.setString(1, kcm);
			pstmt.execute();			
		} catch (SQLException e) {
			return false;
		}
	       return true;
	}
	
	/**
	 * �����޸Ŀγ���Ϣ
	 */
	public static boolean updateCourse(String kcm,int xs,int xf){
		PreparedStatement pstmt=null;

		String sql="update kc set xs=?,xf=? where kcm=?";
		try {
			pstmt=MysqlConn.conns.prepareStatement(sql);			
			pstmt.setInt(1, xs);
			pstmt.setInt(2, xf);			
			pstmt.setString(3, kcm);
			pstmt.execute();
			
		} catch (SQLException e) {
			return false;
		}finally{
	        try{
	        	pstmt.close();
	        }catch(SQLException e){	}	           
		}
		return true;
	}
}



