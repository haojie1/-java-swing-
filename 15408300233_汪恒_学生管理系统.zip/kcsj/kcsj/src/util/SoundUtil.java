package util;
/**
 * ��������������
 */
import java.awt.GridLayout;
import java.io.File;

import javax.sound.midi.MidiSystem;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;
import javax.swing.JPanel;

public class SoundUtil extends JPanel implements Runnable{
	Thread runner;
	String songpath;
	Sequence currentSound;
	Sequencer player;
	
	public SoundUtil(String path){
		songpath=path;
		setLayout(new GridLayout(2,1,5,5));
		if(runner==null){
			runner=new Thread(this);
			runner.start();
		}
	}
	
	@Override
	public void run() {
		try
		{
			File file=new File(songpath);
			//�������
			currentSound=MidiSystem.getSequence(file);
			//���������
			player=MidiSystem.getSequencer();
			player.open();
			//���������������
			player.setSequence(currentSound);
			player.start();		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
}