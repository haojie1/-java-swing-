package util;
/**
 * ͸����幤����
 */
import javax.swing.*;

import util.FrameShowCenterUtil;

import java.awt.*;
import java.awt.event.*;

public class FrameToumingPanelUtil extends JPanel{
	public FrameToumingPanelUtil(){
		this.setLayout(null);
		this.setBackground(null);                      // �ѱ�������Ϊ��  
		this.setOpaque(false);
	}	 
}
