package bean;
/**
 * �γ�javabean
 * @author Administrator
 *
 */
public class Course {
	private String kcm;
	private int xs;
	private int xf;
	
	public String getKcm() {
		return kcm;
	}
	public void setKcm(String kcm) {
		this.kcm = kcm;
	}
	public int getXs() {
		return xs;
	}
	public void setXs(int xs) {
		this.xs = xs;
	}
	public int getXf() {
		return xf;
	}
	public void setXf(int xf) {
		this.xf = xf;
	}
	
	
}
