package bean;
/**
 * ѧ��javabean
 */
import java.io.File;
import java.sql.Date;


public class Student {
	private String xm;
	private String xb;
	private Date cssj;
	private int kcs;
	private String zp;
	
	public Student(String xm,String xb,Date cssj,String zp) {
		this.xm=xm;
		this.xb=xb;
		this.cssj=cssj;
		this.zp=zp;
		
	}

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public String getXm() {
		return xm;
	}
	public void setXm(String xm) {
		this.xm = xm;
	}
	public String getXB() {
		return xb;
	}
	public void setXB(String xB) {
		xb = xB;
	}
	public Date getCssj() {
		return cssj;
	}
	public void setCssj(Date cssj) {
		this.cssj = cssj;
	}
	public int getKcs() {
		return kcs;
	}
	public void setKcs(int kcs) {
		this.kcs = kcs;
	}
	public String getZp() {
		return zp;
	}
	public void setZp(String zp) {
		this.zp = zp;
	}	
}
