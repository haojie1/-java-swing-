package bean;
/**
 * ����Javabean
 * @author Administrator
 *
 */
public class Score {
	private String xm;
	private String kcm;
	private int cj;
	
	public String getXm() {
		return xm;
	}
	public void setXm(String xm) {
		this.xm = xm;
	}
	public String getKcm() {
		return kcm;
	}
	public void setKcm(String kcm) {
		this.kcm = kcm;
	}
	public int getCj() {
		return cj;
	}
	public void setCj(int cj) {
		this.cj = cj;
	}
	
	
}
