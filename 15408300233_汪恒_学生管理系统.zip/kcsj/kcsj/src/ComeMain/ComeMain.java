package ComeMain;
/**
 * ������
 */
import student.main.Login;
public class ComeMain {
	public static void main(String[] args) {
		new Login();
	}
}
