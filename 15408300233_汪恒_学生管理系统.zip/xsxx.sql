/*
Navicat MySQL Data Transfer

Source Server         : 本地mysql
Source Server Version : 50556
Source Host           : localhost:3306
Source Database       : xsxx

Target Server Type    : MYSQL
Target Server Version : 50556
File Encoding         : 65001

Date: 2017-12-19 12:25:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `cj`
-- ----------------------------
DROP TABLE IF EXISTS `cj`;
CREATE TABLE `cj` (
  `xm` char(8) NOT NULL,
  `kcm` char(20) NOT NULL,
  `cj` int(2) DEFAULT NULL,
  PRIMARY KEY (`xm`,`kcm`),
  KEY `xm` (`xm`),
  KEY `kcm` (`kcm`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of cj
-- ----------------------------
INSERT INTO `cj` VALUES ('郭大为', 'C语音', '78');
INSERT INTO `cj` VALUES ('郭大为', 'Java', '88');
INSERT INTO `cj` VALUES ('郭大为', '操作系统', '87');
INSERT INTO `cj` VALUES ('郭大为', '计算机网络', '45');
INSERT INTO `cj` VALUES ('郭大为', '计算机组成原理', '66');
INSERT INTO `cj` VALUES ('郭大为', '毛泽东思想', '77');
INSERT INTO `cj` VALUES ('郭大为', '数据结构', '88');
INSERT INTO `cj` VALUES ('郭大为', '影视鉴赏', '99');
INSERT INTO `cj` VALUES ('郭凡荣', '数据结构', '45');
INSERT INTO `cj` VALUES ('黄盼', 'C++', '77');
INSERT INTO `cj` VALUES ('黄盼', 'C语音', '88');
INSERT INTO `cj` VALUES ('黄盼', 'Java', '99');
INSERT INTO `cj` VALUES ('黄盼', '操作系统', '99');
INSERT INTO `cj` VALUES ('黄盼', '计算机网络', '89');
INSERT INTO `cj` VALUES ('黄盼', '计算机组成原理', '99');
INSERT INTO `cj` VALUES ('黄盼', '毛泽东思想', '89');
INSERT INTO `cj` VALUES ('黄盼', '数据结构', '79');
INSERT INTO `cj` VALUES ('黄盼', '影视鉴赏', '56');
INSERT INTO `cj` VALUES ('李盖文', 'C语音', '89');
INSERT INTO `cj` VALUES ('李盖文', 'Java', '77');
INSERT INTO `cj` VALUES ('李盖文', '操作系统', '99');
INSERT INTO `cj` VALUES ('李盖文', '计算机网络', '78');
INSERT INTO `cj` VALUES ('李盖文', '计算机组成原理', '67');
INSERT INTO `cj` VALUES ('李盖文', '毛泽东思想', '97');
INSERT INTO `cj` VALUES ('李盖文', '数据结构', '78');
INSERT INTO `cj` VALUES ('李盖文', '影视鉴赏', '89');
INSERT INTO `cj` VALUES ('汪恒', 'C++', '98');
INSERT INTO `cj` VALUES ('汪恒', 'C语音', '78');
INSERT INTO `cj` VALUES ('汪恒', 'Java', '100');
INSERT INTO `cj` VALUES ('汪恒', '计算机网络', '88');
INSERT INTO `cj` VALUES ('汪恒', '毛泽东思想', '99');
INSERT INTO `cj` VALUES ('汪恒', '数据结构', '80');

-- ----------------------------
-- Table structure for `kc`
-- ----------------------------
DROP TABLE IF EXISTS `kc`;
CREATE TABLE `kc` (
  `kcm` char(20) NOT NULL,
  `xs` int(2) DEFAULT NULL,
  `xf` int(1) DEFAULT NULL,
  PRIMARY KEY (`kcm`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of kc
-- ----------------------------
INSERT INTO `kc` VALUES ('C++', '34', '4');
INSERT INTO `kc` VALUES ('C语音', '49', '4');
INSERT INTO `kc` VALUES ('Java', '47', '5');
INSERT INTO `kc` VALUES ('编程原理', '40', '4');
INSERT INTO `kc` VALUES ('操作系统', '36', '3');
INSERT INTO `kc` VALUES ('计算机网络', '40', '3');
INSERT INTO `kc` VALUES ('计算机组成原理', '30', '3');
INSERT INTO `kc` VALUES ('毛泽东思想', '45', '3');
INSERT INTO `kc` VALUES ('数据结构', '50', '5');
INSERT INTO `kc` VALUES ('影视鉴赏', '20', '2');

-- ----------------------------
-- Table structure for `xs`
-- ----------------------------
DROP TABLE IF EXISTS `xs`;
CREATE TABLE `xs` (
  `xm` char(8) NOT NULL,
  `xb` char(2) DEFAULT NULL,
  `cssj` date DEFAULT NULL,
  `kcs` int(2) DEFAULT NULL,
  `bz` varchar(500) DEFAULT NULL,
  `zp` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`xm`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of xs
-- ----------------------------
INSERT INTO `xs` VALUES ('郭大为', '男', '1997-08-08', '8', null, 'F:\\xm\\kcsj\\kcsj\\img\\mid_right.jpg');
INSERT INTO `xs` VALUES ('郭凡荣', '男', '1997-09-29', '1', null, 'C:\\Users\\asus\\Desktop\\kcsj\\img\\bj.jpg');
INSERT INTO `xs` VALUES ('黄盼', '男', '1333-02-02', '9', null, 'C:\\Users\\asus\\Desktop\\kcsj\\img\\bj.jpg');
INSERT INTO `xs` VALUES ('李盖文', '男', '1990-09-09', '8', null, 'F:\\xm\\kcsj\\kcsj\\img\\aaa.jpg');
INSERT INTO `xs` VALUES ('汪恒', '男', '1997-08-28', '6', null, 'F:\\xm\\kcsj\\kcsj\\img\\aaa.jpg');
INSERT INTO `xs` VALUES ('展万里', '男', '2017-07-04', '0', null, 'F:\\xm\\kcsj\\kcsj\\img\\aaa.jpg');
INSERT INTO `xs` VALUES ('张三', '男', '1997-08-28', '0', null, 'F:\\xm\\kcsj\\kcsj\\img\\touxiang.jpeg');

-- ----------------------------
-- Table structure for `zhanghaomima`
-- ----------------------------
DROP TABLE IF EXISTS `zhanghaomima`;
CREATE TABLE `zhanghaomima` (
  `zhanghao` char(20) NOT NULL,
  `mima` char(20) NOT NULL,
  PRIMARY KEY (`zhanghao`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of zhanghaomima
-- ----------------------------
INSERT INTO `zhanghaomima` VALUES ('stu', '123456');
INSERT INTO `zhanghaomima` VALUES ('sys', '123');
INSERT INTO `zhanghaomima` VALUES ('郭大为', '123456');
INSERT INTO `zhanghaomima` VALUES ('郭凡荣', '123456');
INSERT INTO `zhanghaomima` VALUES ('黄盼', '123456');
INSERT INTO `zhanghaomima` VALUES ('李盖文', '123456');
INSERT INTO `zhanghaomima` VALUES ('汪恒', '123456');
INSERT INTO `zhanghaomima` VALUES ('展万里', '123456');
INSERT INTO `zhanghaomima` VALUES ('张三', '123456');
